package com.astha.Controller;

import com.astha.bean.Course;
import com.astha.bean.faculty;
import com.astha.bean.student;
import com.astha.util.SessionUtil;
import org.hibernate.Session;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

//@Path("myresource")
//public class login {
//
//    @GET
//    @Produces(MediaType.TEXT_PLAIN)
//    public String getIt() {


        //student s=new student();
//        faculty f1=new faculty();
//        faculty f2=new faculty();
//
//        Course c1=new Course();
//        Course c2=new Course();
//        c1.setCname("Algo");
//       c2.setCname("Network");
//        //c3.setCname("system software");
//        //c4.setCname("Machine learning");
//
//
//        f1.setFname("Abhishek");
//        f1.setFpassword("abhishek");
//
////        s.setName("Astha");
////        s.setPassword("Astha");
//
//        f2.setFname("Abhi");
//        f2.setFpassword("abhishek");
//        c1.getFaculty().add(f1);
//        c1.getFaculty().add(f2);
////
//        f1.setCour(c1);
//        f2.setCour(c1);
//        Session session = SessionUtil.getSession();
//
//        session.beginTransaction();
//
//
//        session.save(f1);
//        session.save(f2);
//        session.save(c1);
//        session.save(c2);
//
//
//        session.getTransaction().commit();
//        session.close();
//    return "Got it!";
//    }
//
//
//}



import java.io.InputStream;
import java.net.URI;
import java.net.URISyntaxException;

import javax.management.Query;
import javax.persistence.criteria.CriteriaBuilder;
import javax.ws.rs.Consumes;
import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

//import org.glassfish.jersey.media.multipart.FormDataContentDisposition;
//import org.glassfish.jersey.media.multipart.FormDataParam;
import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Restrictions;

//import model.Faculty;
//import util.SessionUtil;



@Path("/login")
public class login {
    @POST
//@Consumes(MediaType.MULTIPART_FORM_DATA)
    @Produces(MediaType.TEXT_PLAIN)

    public Response checkCredentials(@FormParam("exampleInputEmail1") String username, @FormParam("exampleInputPassword1") String password
    ) throws URISyntaxException {
        System.out.println("hii");
        Session session = SessionUtil.getSession();
        try { Transaction tx= session.beginTransaction();
   /*String hql ="FROM" +Faculty.class.getName()+ " di WHERE di.uname LIKE :uname";
   Query query = (Query) session.createQuery(hql);
   ((org.hibernate.query.Query) query).setParameter("uname", "%" + username + "%");
   */

            Criteria criteria=session.createCriteria(faculty.class);
            CriteriaBuilder builder = session.getCriteriaBuilder();
            criteria.add(Restrictions.eq("uname",username));


            faculty f=(faculty)criteria.uniqueResult();
            if(f!=null)
            {   System.out.println(f.getFname());
                System.out.println(f.getFpassword());
                if(f.getFpassword().equals(password))
                    return Response.seeOther(new URI("/SoftwareProject/facultyhomepage.html")).build();
            }
            else
            {
                return Response.noContent().build();

            }
            tx.commit();
            session.close();


        }
        catch(HibernateException e)
        {
            e.printStackTrace();
            session.getTransaction().rollback();
        }
        return null;


    }


}